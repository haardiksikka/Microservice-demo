package com.comviva.microservicedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicedemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
