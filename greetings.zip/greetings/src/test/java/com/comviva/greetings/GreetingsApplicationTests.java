package com.comviva.greetings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreetingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
